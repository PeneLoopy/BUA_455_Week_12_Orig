Copy and Paste Name of R Project - README
Last Edit: 2022-??-??
============================================================

This R project was created by ____________ (Fill in Name). 
This R project contains one folder with 3 types of R files:

Folder: code_data_output

-----------
CODE FILES:
-----------

List all R Scripts and R Markdown files used in this R Project


- R Scripts:
    

- R Markdown Files:


-----------
DATA FILES:
-----------

External datasets imported into R for the project are listed here.


-------------
OUTPUT FILES:
-------------

Output files such as documents, images, or tabular output are listed here.


- HTML Output:


- Images:


============================================================
In addition to this folder, the following files are contained in this project:

- This README file

- The _____________.Rproj file that contains all of the project settings and links.